import p1 from './images/p1.jpg';
import p2 from './images/p2.jpg';
import p3 from './images/p3.jpg';
import p4 from './images/p4.jpg';
import p5 from './images/p5.jpg';
import p6 from './images/p6.jpg';

const data=
        [
        {
        id:'1',
        oid:'344',
        name:'OnePlus 9RT ',
        price:27999,
        desc:" Blue Ray,12GB RAM,256GB Storage",
        image:p1,
        quantity:"In Stock",
        status:"Dispatched",
        orderdate:"10th feb,Thursday",
        deliverydate:"12th Feb,sunday"
        },
        {
            id:'2',
            oid:'445',
            name:'OnePlus Nord 2',
            price:39999,
            desc:" Purple Ray,12GB RAM,256GB Storage",
            image:p2,
            quantityy:"Only 2 left in Stock",
            status:"Delivery by sunday",
            orderdate:"10th Feb,Thursday",
            deliverydate:"12th feb,sunday"
        },
        {
            id:'3',
            oid:'366',
            name:'OnePlus Nord CE',
            price:25999,
            desc:"Black Ray,12GB RAM,256GB Storage.",
            image:p3,
            quantity:"In Stock",
            status:"Pending",
            orderdate:"8th feb,Friday",
            deliverydate:"13th Feb,Monday"
        },    
        {
            id:'4',
            oid:'665',
            name:'OnePlus Nord CE',
            price:26999,
            desc:"Green Ray,12GB RAM,256GB Storage",
            image:p4,
            quantity:"In Stock",
            status:"Delivered",
            orderdate:"6th feb,Sunday",
            deliverydate:"9th feb,wednesday",
            },
            {
                id:'5',
                oid:'894',
                name:'OnePlus 8RT',
                price:31999,
                desc:"Gray Ray,12GB RAM,256GB Storage",
                image:p5,
                quantity:"In Stock",
                status:"Delivery by wednesday",
                orderdate:"10th feb,Wednesday",
                deliverydate:"13th Feb,Wenesday"
            },
            {
                id:'6',
                oid:'445',
                name:'OnePlus Nord CE 5G',
                price:39999,
                desc:"Pac Man edition,12GBRAM,256GB Storage.",
                image:p6,
                quantityy:"Out of Stock",
                Note:" We will Notify you when it is back in stock"
            },     
    ]

export default data;