
import './App.css';
import Navbar from './components/navbar';
import {CartProvider} from "react-use-cart";
import Footer from './components/footer';
import Register from './components/Register';
import {
  BrowserRouter as Router,
  Switch,
  Route
} from "react-router-dom";
import Home from './components/Home';
import Login from './components/login';
import Cart from './components/cart';
import About from './components/About'
import Contact from './components/Contact';
import ProductDetails from './components/ProductDetail';
import Payhome from './components/Payhome';
import Payment from './components/Payment';
import Ty from './components/Ty'
import history from './components/history';
import Postadmin from './components/postadmin';
import Admin from './components/admin';
import Users from './components/allusers';
import Profile from './components/profile';
import MessageTemplate from './components/chat';
import Logout from './components/logout';
import OrderTracker from './components/ordertracking';
import OrderHistory from './components/orderhistory';
function App() {
  
  return (
     <div className="App">
        <Router history>
       <CartProvider>
     
          <Switch>
          <Route exact path='/Register' component={Register}/>
          <Route exact path='/Payhome' component={Payhome}/>
          <Route exact path='/home' component={Home} />
          <Route exact path='/' component={Login} />
          <Route exact path='/Cart' component={Cart} />
          <Route exact path='/About' component={About}/>
          <Route exact path='/Contact' component={Contact}/>
          <Route exact path='/product/:id' component={ProductDetails}/>
          <Route exact path='/Ty' component={Ty}/>
          <Route exact path='/Profile' component={Profile}/>
          <Route exact path='/adminlogin' component={Admin}/>
          <Route exact path='/Users' component={Users}/>
          <Route exact path='/chat' component={MessageTemplate}/>
          <Route exact path='/orderhistory' component={OrderHistory}/>
          <Route exact path='/ordertracker' component={OrderTracker}/>
          </Switch>
          </CartProvider>
          <Footer ></Footer >
          </Router>
   </div>
  );
}

export default App;
