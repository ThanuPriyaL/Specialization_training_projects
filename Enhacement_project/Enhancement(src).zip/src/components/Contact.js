import React, { Component } from 'react';
import {Link,Redirect} from "react-router-dom";
import Navbar from '../components/navbar';
// import './About.css';
// import Cha
import c from '../images/c1.jpg';
import './con.css'
function Conatct(){
    return(
        <div>
            <Navbar/>

             <div class="wrapper">
             <div class="background-container">
             <div class="bg-1"></div>
             <div class="bg-2"></div>
</div>
<div class="about-container">
    
    <div class="text-container">
        <h1>Contact Us</h1>
        <div class="inner-container1">
<form>
<div className='text'>
<label htmlFor="firstname">Drop a Message</label>
<span></span>
<input type="text"required />
</div>
</form>
</div>
<div class="col-md-6 col-lg-7 mb-2 mb-md-0">
        <a href="">Send Message</a> <hr></hr> 
         {/* <h6>OR</h6>  */}
       
       
<Link to={'/chat'} class="link">  <a href="">Chat with us</a> </Link>

</div>
    </div> 
    <div class="image-container">
        <img src={c}></img>     
    </div>

    
</div>
</div>

        </div>
    )
}
export default Conatct;