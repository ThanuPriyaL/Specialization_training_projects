// import React from 'react';
// import axios from 'axios';
// import history from './history';
// import {Redirect} from "react-router-dom";

// import {
//     Link
//   } from "react-router-dom";
//   import { FaUserCircle,FaEnvelope,FaKey,FaUser} from 'react-icons/fa';
// class Postadmin extends React.Component {
//     constructor(props) {
//         super(props);
//         this.state = {
            
//             email: '',
            
//             pass:''
//         }
//     }
//     handleChange = event => {
//         this.setState({ [event.target.name]: event.target.value })
//     }
//     handleSubmit = event => {
//         event.preventDefault()
//         axios.post('http://localhost:8080/saveadmin', this.state)
//             .then(res => {
//                 console.log(res.data)
//                 // {redirect:true}
                
//             })
//             .catch(err => {
//                 console.log(err)
                
//             })
//         console.log(this.state);
       
        
//     }
//     render() { 
//         const {email,pass } = this.state
//         return ( 
//             <div class="wrapperrr">
//                   {/* {this.state.redirect?(<Redirect push to="/" />):null} */}
//             <div class="text-center mt-4 name"> Admin Sign In </div>
//     <form class="p-3 mt-3" onSubmit={this.handleSubmit}>
   

//     <div class="form-field d-flex align-items-center"><FaEnvelope></FaEnvelope>
//     <span class="fas fa-mail"></span> 
//     <input type="email" name="email"  value ={email} onChange={this.handleChange}  required placeholder="Enter your Email"/> </div>
    
    
//     <div class="form-field d-flex align-items-center"><FaKey></FaKey>
//     <span class="fas fa-user"></span> 
//     <input type="password" name="pass" value={pass} onChange={this.handleChange} required placeholder="Enter your Password"/></div>
    
    
//        <button class="btn mt-3"  type="submit">Admin Register</button>
     
//       {/* <button class="btn mt-3"  type="submit" onClick={()=>history.push('/')}>Regsiter</button> */}
//     </form>
//     <div class="text-center fs-6"> <Link to="adminlogin"><a>Admin Log in</a> </Link> </div>
//     </div>
    
//          );
//     }
// }
 
// export default Postadmin;