import React from 'react';
import {useCart} from "react-use-cart";
import {Link} from 'react-router-dom'
import Navbar from '../components/navbar';
const OrderHistory=()=>{ 
        const{
            items,
            isEmpty,
            totalUniqueItems,
            totalItems,
            cartTotal,
            updateItemQuantity,
            removeItem,
            emptyCart
    }=useCart();
    // if(isEmpty) return <h1 className='text-center'>your cart is empty</h1>
        return(
            <div>
                <Navbar/>
            
            <section className="py-4 container">
                <div className="row justify-content-center">
                    <div className="col-12">
                        <h5> Total Items:({totalItems})</h5>
                        <table className='table table-light table-hover m-0'>
                            <thead>  <tr>
                                <th>Product Id</th>
                                <th>Product </th>
                                <th>Product Description</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Order Date</th>
                                <th>Order Status</th>
                                <th>Delivery Date</th>
                                <th>Action</th>

                            </tr>
                            </thead>
                            <tbody>
                            
                            {items.map((item,index)=>{
                                return(
                                <tr key={index}>
                                     <td>{item.id}</td>
                                    <td>
                                        <img src={item.image} style={{height:'6rem'}}/>
                                    </td>
                                   
                                    <td>{item.name}</td>
                                    <td>{item.price}</td>
                                    <td>Quantity({item.quantity})</td>
                                    <td>{item.orderdate}</td>
                                    <td>{item.status}</td>
                                    <td>{item.deliverydate}</td>
                                    <td><Link to={'/Payhome'}>Buy Again</Link></td>
                                </tr>
                                );
                            })}
                            </tbody>
                        </table>
                    </div>
                    <div className="col-auto ms-auto">
                        {/* <h3>Total Price: {cartTotal}</h3> */}
                        
                    {/* <div classname="col-auto">
                        <button className="btn btn-dark m-2" onClick={emptyCart}>Clear Cart</button>
                        <Link to="/Payhome"><button className="btn btn-dark m-2">Buy Now</button></Link>
                        </div> */}
                    </div>
                </div>
           </section>
           </div>
        );
};
 
// export default Cart;
export default OrderHistory;

