import React, { Component } from 'react';
import './About.css';
import Navbar from '../components/navbar';
import bg from '../images/bg.jpg';
function About(){
return(
<div>
    <Navbar/>
<div class="wrapper">
<div class="background-container">
<div class="bg-1"></div>
<div class="bg-2"></div>
</div>
<div class="about-container">

<div class="image-container">
<img src={bg}></img>

</div>



<div class="text-container">
<h1>About us</h1>
<h6>OnePlus Technology Co., Ltd. is a Consumer electronics manufacturer headquartered in   <br></br>Shenzhen, Guangdong province, in the Tairan Building at the Chegong Temple subdistrict of Futian District.</h6>
<a href="">Read More</a>
</div>

</div>
</div>
</div>
)
}
export default About;