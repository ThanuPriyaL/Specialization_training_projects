import * as React from 'react';
import * as ReactDOM from 'react-dom';
import './chat.css';
import { FaPaperPlane } from 'react-icons/fa';
import { Chat } from '@progress/kendo-react-conversational-ui';



class MessageTemplate extends React.Component {
user = {
id: 1,
// avatarUrl: "https://via.placeholder.com/24/008000/008000.png"
// https://www.telerik.com/kendo-react-ui/components/installation/source-code/
};
bot = {
id: 0
};
state = {
messages: [{
author: this.bot,
suggestedActions: [{
type: 'reply',
// value: 'How can I help you ?'
}],
text: "Hii",
// timestamp: new Date()
}]
};
addNewMessage = event => {
let botResponce = Object.assign({}, event.message);
botResponce.text = this.countReplayLength(event.message.text);
botResponce.author = this.bot;
this.setState(prevState => ({
messages: [...prevState.messages, event.message]
}));
setTimeout(() => {
this.setState(prevState => ({
messages: [...prevState.messages, botResponce]
}));
}, 1000);
};
countReplayLength = question => {
let length = question.length;
let answer = "How can i help you ?";
return answer;
};



render() {

return(
    <div> <Navbar/> <div class="chat" >
<div class="chatuser" >

<Chat user={this.user} messages={this.state.messages} onMessageSend={this.addNewMessage} placeholder={"Type a message..."} width={400} />



</div>
</div>
</div>);
}



}



// ReactDOM.render(<App />, document.querySelector('my-app'));
export default MessageTemplate;