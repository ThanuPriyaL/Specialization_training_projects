import React from "react";
import './login.css';
import {Link,Redirect} from "react-router-dom";
import { FaGoogle,FaEnvelope,FaKey} from 'react-icons/fa';
  import axios from "axios";
class Login extends React.Component{
    
    constructor(props) {
        super(props);
        this.state = {
            email: '',
            pass:'',
            msg:'',
            redirect:false
        }
    }  

    handleSubmit=event=>{
        event.preventDefault()
        axios.post('http://localhost:8080/login', this.state)
            .then(res => {
                console.log("login successfull")
                this.setState(
                    {redirect:true}
                )
                
            })
            .catch(err => {
                console.log("invalid credentials")
                this.setState({msg:"invalid username or password"})
            })
    }
    handleChange=event=>{
        this.setState({ [event.target.name]: event.target.value })
        
    }
    render(){

        const{email,pass}=this.state
        
    return(

    <div class="wrapperr">
 
        {this.state.redirect?(<Redirect push to="/" />):null}
<div class="text-center mt-4 name"> Log In </div>
<form class="p-3 mt-3">
<div class="form-field d-flex align-items-center"> <FaEnvelope></FaEnvelope>
<span class="far fa-user"></span> 

<input type="email" name="email" id="email" value={email} required placeholder="Enter your Email"onChange={this.handleChange}/> </div>

<div class="form-field d-flex align-items-center" > <FaKey></FaKey>


<input type="password" name="pass" id="password" required value={pass} onChange={this.handleChange} placeholder="Password" /> </div> 

   <button class="btn mt-3"  type="submit" onClick={this.handleSubmit}>Log in</button>
   <p>{this.state.msg}</p>
</form>
<div style={{width:"350px"}}>
            <a class="btn btn-primary btn-sm " style={{ backgroundColor: "#3b5998",paddingLeft: "45px",width:"300px",marginLeft: "55px"}} href="https://www.facebook.com/" role="button">
                  <i class="fab fa-facebook-f me-2"></i>Continue with Facebook
                </a>
                <div className="float-end" style={{ paddingTop:"15px",width:"350px",paddingLeft:"60px",marginLeft: "45px"}}>
                <a class="btn btn-primary btn-sm " style={{ backgroundColor: "#55acee"}} href="https://twitter.com/i/flow/login?input_flow_data=%7B%22requested_variant%22%3A%22eyJsYW5nIjoiZW4ifQ%3D%3D%22%7D" role="button">
                  <i class="fab fa-twitter me-2"></i>Continue with Twitter</a>&ensp;<br></br>
                 </div>
                  <a class="btn btn-primary btn-sm " style={{ backgroundColor: "rgb(245, 78, 78",marginLeft: "55px",width:"300px",paddingLeft:"45px"}}  href="https://accounts.google.com/SignUp?hl=en" role="button">
                    <i class="fab fa-google me-2"></i>Continue with Google</a> </div>
<div class="text-center fs-6" style={{ paddingTop:"20px"}} > <Link to="Register"><a><h6>Sign up ? New Customer start here</h6></a> </Link></div>

<div class="admin" style={{}}>
<Link to={'/adminlogin'} class="link"><h6>Admin Login</h6></Link></div>
</div>


         
    );
    }
}
export default Login;