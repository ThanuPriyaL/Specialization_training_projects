import { Component, OnInit } from '@angular/core';
import { Router} from'@angular/router';
@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  mess:string="";
  valid:boolean=false;
  prop:string="";
  demo:any=[
  {'email':'mahi@gmail.com','pass':123},
  {'email':'thanu@gmail.com','pass':123},
  {'email':'santosh@gmail.com','pass':123},
  {'email':'prateek@gmail.com','pass':123},
  ]
  constructor(private router: Router) { }
  
  ngOnInit(): void {
  }
  login(value: any,pageName: String){
  
  
  // if(value.emailid == this.demo.emailid && value.password == this.demo.password){
  
  if(value.email == "mahi@gmail.com" && value.pass == "123"){
  this.mess=`Admin Successfully logged in`;
  this.prop=`#006400`;
  this.valid=true;
  this.router.navigate(['/AllUsers'])
  // if(this.valid== true){
  // return`<a routerLink="/" >`;
  // }
  }
  else {
  this.mess=`Admin Login not succesful`;
  this.prop=`red`;
  this.valid=false
  
  }
  console.log(value.emailid);
  console.log(value.password);

}
  // }
  
  }
